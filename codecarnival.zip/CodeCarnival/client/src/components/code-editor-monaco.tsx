import { useEffect, useRef } from "react";
import * as monaco from "monaco-editor";

interface CodeEditorMonacoProps {
  value: string;
  onChange: (value: string) => void;
  language: string;
  theme?: string;
  readOnly?: boolean;
  className?: string;
}

export default function CodeEditorMonaco({
  value,
  onChange,
  language,
  theme = "vs",
  readOnly = false,
  className = "",
}: CodeEditorMonacoProps) {
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Create the editor
    editorRef.current = monaco.editor.create(containerRef.current, {
      value,
      language,
      theme,
      readOnly,
      automaticLayout: true,
      minimap: { enabled: false },
      fontSize: 14,
      lineNumbers: "on",
      roundedSelection: false,
      scrollBeyondLastLine: false,
      wordWrap: "on",
      tabSize: 2,
      insertSpaces: true,
      formatOnPaste: true,
      formatOnType: true,
    });

    // Set up change listener
    const disposable = editorRef.current.onDidChangeModelContent(() => {
      if (editorRef.current) {
        onChange(editorRef.current.getValue());
      }
    });

    return () => {
      disposable.dispose();
      if (editorRef.current) {
        editorRef.current.dispose();
      }
    };
  }, []);

  // Update value when prop changes
  useEffect(() => {
    if (editorRef.current && editorRef.current.getValue() !== value) {
      editorRef.current.setValue(value);
    }
  }, [value]);

  // Update language when prop changes
  useEffect(() => {
    if (editorRef.current) {
      const model = editorRef.current.getModel();
      if (model) {
        monaco.editor.setModelLanguage(model, language);
      }
    }
  }, [language]);

  // Update theme when prop changes
  useEffect(() => {
    monaco.editor.setTheme(theme);
  }, [theme]);

  return (
    <div 
      ref={containerRef} 
      className={`monaco-editor-container ${className}`}
      style={{ height: "100%", width: "100%" }}
    />
  );
}
