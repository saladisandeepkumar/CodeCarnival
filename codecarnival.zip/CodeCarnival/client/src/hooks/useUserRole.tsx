import { useQuery } from "@tanstack/react-query";

export function useUserRole() {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  return {
    user,
    isAdmin: (user as any)?.role === 'admin',
    isLoading,
  };
}