import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import CodeEditorMonaco from "@/components/code-editor-monaco";

// Language starter code templates
const starterCode = {
  python: `def solve(nums, target):
    # Write your solution here
    pass

# Test your solution
if __name__ == "__main__":
    nums = [2, 7, 11, 15]
    target = 9
    result = solve(nums, target)
    print(result)`,
  
  javascript: `function solve(nums, target) {
    // Write your solution here
    
}

// Test your solution
const nums = [2, 7, 11, 15];
const target = 9;
const result = solve(nums, target);
console.log(result);`,
  
  java: `import java.util.*;

public class Solution {
    public int[] solve(int[] nums, int target) {
        // Write your solution here
        return new int[]{};
    }
    
    public static void main(String[] args) {
        Solution solution = new Solution();
        int[] nums = {2, 7, 11, 15};
        int target = 9;
        int[] result = solution.solve(nums, target);
        System.out.println(Arrays.toString(result));
    }
}`,
  
  cpp: `#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    vector<int> solve(vector<int>& nums, int target) {
        // Write your solution here
        return {};
    }
};

int main() {
    Solution solution;
    vector<int> nums = {2, 7, 11, 15};
    int target = 9;
    vector<int> result = solution.solve(nums, target);
    
    for (int i : result) {
        cout << i << " ";
    }
    cout << endl;
    
    return 0;
}`,
};

export default function CodeEditor() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const params = useParams();
  const problemId = params.id;
  
  const [selectedLanguage, setSelectedLanguage] = useState("python");
  const [code, setCode] = useState(starterCode.python);
  const [testResults, setTestResults] = useState<any>(null);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: problem, isLoading: problemLoading } = useQuery({
    queryKey: ["/api/problems", problemId],
    retry: false,
    enabled: !!problemId,
  });

  const submitCodeMutation = useMutation({
    mutationFn: async (submissionData: any) => {
      const response = await apiRequest("POST", "/api/submissions", submissionData);
      return response.json();
    },
    onSuccess: (submission) => {
      toast({
        title: "Code Submitted",
        description: "Your solution has been submitted for evaluation.",
      });
      
      // Simulate test results for demo
      setTimeout(() => {
        setTestResults({
          status: "accepted",
          testCasesPassed: 3,
          totalTestCases: 3,
          runtime: 45,
          memory: 14.2,
        });
      }, 2000);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to submit code",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    // Update code when language changes
    if (problem?.starterCode && problem.starterCode[selectedLanguage]) {
      setCode(problem.starterCode[selectedLanguage]);
    } else {
      setCode(starterCode[selectedLanguage as keyof typeof starterCode] || starterCode.python);
    }
  }, [selectedLanguage, problem]);

  if (isLoading || problemLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-brand-600"></div>
      </div>
    );
  }

  if (!problem) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Problem Not Found</h1>
          <p className="text-gray-600">The requested problem could not be found.</p>
        </div>
      </div>
    );
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-amber-100 text-amber-800';
      case 'hard':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleRunCode = () => {
    // Simulate code execution
    toast({
      title: "Running Code",
      description: "Executing your code with sample test cases...",
    });
    
    setTimeout(() => {
      setTestResults({
        isRun: true,
        output: "Sample output:\n[0, 1]",
        status: "success",
      });
    }, 1500);
  };

  const handleSubmitCode = () => {
    if (!code.trim()) {
      toast({
        title: "Error",
        description: "Please write some code before submitting.",
        variant: "destructive",
      });
      return;
    }

    submitCodeMutation.mutate({
      problemId,
      language: selectedLanguage,
      code: code,
    });
  };

  const handleResetCode = () => {
    if (problem?.starterCode && problem.starterCode[selectedLanguage]) {
      setCode(problem.starterCode[selectedLanguage]);
    } else {
      setCode(starterCode[selectedLanguage as keyof typeof starterCode] || starterCode.python);
    }
    setTestResults(null);
  };

  return (
    <div className="h-screen flex">
      {/* Problem Description */}
      <div className="w-1/2 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-semibold text-gray-900">{problem.title}</h1>
            <Badge className={getDifficultyColor(problem.difficulty)}>
              {problem.difficulty}
            </Badge>
          </div>
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <span>{problem.acceptanceRate || 0}% acceptance</span>
            <span>{problem.submissionCount || 0} submissions</span>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6">
          <div className="prose prose-sm max-w-none">
            <div 
              className="text-gray-800 leading-relaxed"
              dangerouslySetInnerHTML={{ 
                __html: problem.description.replace(/\n/g, '<br/>') 
              }}
            />
            
            {problem.testCases && problem.testCases.length > 0 && (
              <div className="mt-6">
                <h4 className="font-semibold text-gray-900 mb-3">Examples:</h4>
                {problem.testCases.slice(0, 2).map((testCase: any, index: number) => (
                  <div key={index} className="mb-4 p-4 bg-gray-50 rounded-lg">
                    <div className="font-mono text-sm">
                      <div className="mb-2">
                        <strong>Input:</strong> {JSON.stringify(testCase.input)}
                      </div>
                      <div className="mb-2">
                        <strong>Output:</strong> {JSON.stringify(testCase.expected)}
                      </div>
                      {testCase.explanation && (
                        <div>
                          <strong>Explanation:</strong> {testCase.explanation}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {problem.topics && problem.topics.length > 0 && (
              <div className="mt-6">
                <h4 className="font-semibold text-gray-900 mb-2">Topics:</h4>
                <div className="flex flex-wrap gap-2">
                  {problem.topics.map((topic: string) => (
                    <Badge key={topic} variant="secondary" className="text-xs">
                      {topic}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Code Editor */}
      <div className="w-1/2 flex flex-col">
        {/* Editor Header */}
        <div className="bg-gray-50 border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="python">Python</SelectItem>
                  <SelectItem value="javascript">JavaScript</SelectItem>
                  <SelectItem value="java">Java</SelectItem>
                  <SelectItem value="cpp">C++</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="ghost" size="sm" onClick={handleResetCode}>
                Reset
              </Button>
            </div>
            <div className="flex items-center space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleRunCode}
              >
                Run
              </Button>
              <Button 
                size="sm"
                onClick={handleSubmitCode}
                disabled={submitCodeMutation.isPending}
              >
                {submitCodeMutation.isPending ? "Submitting..." : "Submit"}
              </Button>
            </div>
          </div>
        </div>

        {/* Editor */}
        <div className="flex-1 relative">
          <CodeEditorMonaco
            value={code}
            onChange={setCode}
            language={selectedLanguage === 'cpp' ? 'cpp' : selectedLanguage}
            className="h-full"
          />
        </div>

        {/* Test Results */}
        <div className="bg-gray-50 border-t border-gray-200 p-4 max-h-48 overflow-y-auto">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-medium text-gray-900">
              {testResults?.isRun ? "Run Results" : "Test Results"}
            </h4>
            {testResults && (
              <span className={`text-sm ${
                testResults.status === 'accepted' || testResults.status === 'success'
                  ? 'text-green-600' 
                  : 'text-red-600'
              }`}>
                {testResults.isRun 
                  ? 'Code executed successfully'
                  : `${testResults.testCasesPassed || 0}/${testResults.totalTestCases || 0} passed`
                }
              </span>
            )}
          </div>
          
          {testResults ? (
            <div className="space-y-2 text-sm">
              {testResults.isRun ? (
                <div className="p-3 bg-white rounded border">
                  <pre className="whitespace-pre-wrap text-gray-800">
                    {testResults.output}
                  </pre>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                    <span className="text-green-800">Test Case 1</span>
                    <span className="text-green-600">✓ Passed</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                    <span className="text-green-800">Test Case 2</span>
                    <span className="text-green-600">✓ Passed</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                    <span className="text-green-800">Test Case 3</span>
                    <span className="text-green-600">✓ Passed</span>
                  </div>
                  {testResults.runtime && (
                    <div className="text-xs text-gray-500 mt-2">
                      Runtime: {testResults.runtime}ms • Memory: {testResults.memory}MB
                    </div>
                  )}
                </>
              )}
            </div>
          ) : (
            <div className="text-sm text-gray-500">
              Run your code to see the output, or submit to test against all cases.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
