import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Link } from "wouter";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useUserRole } from "@/hooks/useUserRole";
import { Settings, Plus } from "lucide-react";

export default function Contests() {
  const { toast } = useToast();
  const { isAdmin } = useUserRole();
  const [filters, setFilters] = useState({
    status: "all",
    search: "",
    page: 1
  });

  const { data: contestsData, isLoading } = useQuery({
    queryKey: ["/api/contests", filters],
    retry: false,
  });

  const registerMutation = useMutation({
    mutationFn: async (contestId: string) => {
      await apiRequest("POST", `/api/contests/${contestId}/register`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Successfully registered for the contest!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/contests"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to register for contest",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming':
        return 'bg-blue-100 text-blue-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleRegister = (contestId: string) => {
    registerMutation.mutate(contestId);
  };

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value,
      page: 1
    }));
  };

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">Contests</h1>
                  <p className="text-gray-600">Participate in coding contests and compete with other developers</p>
                </div>
                {isAdmin && (
                  <div className="flex items-center space-x-3">
                    <Link href="/admin/contests" data-testid="link-admin-contests">
                      <Button variant="outline" className="flex items-center space-x-2">
                        <Settings className="w-4 h-4" />
                        <span>Manage Contests</span>
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </div>

            {/* Filters */}
            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-gray-900">All Contests</h2>
                  <div className="flex items-center space-x-3">
                    <Select 
                      value={filters.status} 
                      onValueChange={(value) => handleFilterChange('status', value)}
                    >
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="All Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="upcoming">Upcoming</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      type="search"
                      placeholder="Search contests..."
                      className="w-64"
                      value={filters.search}
                      onChange={(e) => handleFilterChange('search', e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contests List */}
            <div className="space-y-6">
              {isLoading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600 mx-auto"></div>
                </div>
              ) : (contestsData as any)?.contests && (contestsData as any).contests.length > 0 ? (
                (contestsData as any).contests.map((contest: any) => (
                  <Card key={contest.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-semibold text-gray-900">{contest.title}</h3>
                            <Badge className={getStatusColor(contest.status)}>
                              {contest.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-4">{contest.description}</p>
                          <div className="grid grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500">Start:</span>
                              <span className="text-gray-900 ml-1">
                                {new Date(contest.startTime).toLocaleDateString()} at{' '}
                                {new Date(contest.startTime).toLocaleTimeString()}
                              </span>
                            </div>
                            <div>
                              <span className="text-gray-500">Duration:</span>
                              <span className="text-gray-900 ml-1">{contest.duration} minutes</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Participants:</span>
                              <span className="text-gray-900 ml-1">
                                {contest.maxParticipants ? `0/${contest.maxParticipants}` : '0'}
                              </span>
                            </div>
                            <div>
                              <span className="text-gray-500">End:</span>
                              <span className="text-gray-900 ml-1">
                                {new Date(contest.endTime).toLocaleDateString()} at{' '}
                                {new Date(contest.endTime).toLocaleTimeString()}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 ml-6">
                          {contest.status === 'upcoming' && (
                            <Button
                              onClick={() => handleRegister(contest.id)}
                              disabled={registerMutation.isPending}
                            >
                              {registerMutation.isPending ? "Registering..." : "Register"}
                            </Button>
                          )}
                          {contest.status === 'active' && (
                            <Button>
                              Join Contest
                            </Button>
                          )}
                          {contest.status === 'completed' && (
                            <Button variant="outline">
                              View Results
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="p-12 text-center">
                    <p className="text-gray-500">No contests found</p>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Pagination */}
            {(contestsData as any)?.total && (contestsData as any).total > 20 && (
              <div className="mt-6 flex items-center justify-between">
                <p className="text-sm text-gray-700">
                  Showing {((filters.page - 1) * 20) + 1}-{Math.min(filters.page * 20, (contestsData as any).total)} of {(contestsData as any).total} contests
                </p>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    disabled={filters.page === 1}
                    onClick={() => handleFilterChange('page', filters.page - 1)}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    className="bg-brand-600 text-white"
                  >
                    {filters.page}
                  </Button>
                  <Button
                    variant="outline"
                    disabled={filters.page * 20 >= (contestsData as any).total}
                    onClick={() => handleFilterChange('page', filters.page + 1)}
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
