import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";

export default function AdminContests() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [filters, setFilters] = useState({
    status: "all",
    search: "",
    page: 1
  });
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  // Redirect to home if not authenticated or not admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || (user as any)?.role !== 'admin')) {
      toast({
        title: "Unauthorized",
        description: "Admin access required. Redirecting...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: contestsData, isLoading: contestsLoading } = useQuery({
    queryKey: ["/api/contests", filters],
    retry: false,
    enabled: (user as any)?.role === 'admin',
  });

  const createContestMutation = useMutation({
    mutationFn: async (contestData: any) => {
      const response = await apiRequest("POST", "/api/contests", contestData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Contest created successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/contests"] });
      setIsCreateModalOpen(false);
      reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to create contest",
        variant: "destructive",
      });
    },
  });

  const deleteContestMutation = useMutation({
    mutationFn: async (contestId: string) => {
      await apiRequest("DELETE", `/api/contests/${contestId}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Contest deleted successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/contests"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to delete contest",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-brand-600"></div>
      </div>
    );
  }

  if (user?.role !== 'admin') {
    return null;
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming':
        return 'bg-blue-100 text-blue-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value,
      page: 1
    }));
  };

  const handleDeleteContest = (contestId: string, contestTitle: string) => {
    if (window.confirm(`Are you sure you want to delete "${contestTitle}"? This action cannot be undone.`)) {
      deleteContestMutation.mutate(contestId);
    }
  };

  const onSubmitContest = (data: any) => {
    // Convert form data to proper format
    const contestData = {
      title: data.title,
      description: data.description,
      startTime: new Date(data.startTime).toISOString(),
      endTime: new Date(data.endTime).toISOString(),
      duration: parseInt(data.duration),
      maxParticipants: data.maxParticipants ? parseInt(data.maxParticipants) : null,
    };

    createContestMutation.mutate(contestData);
  };

  // Mock stats for demonstration
  const adminStats = {
    totalContests: (contestsData as any)?.total || 0,
    totalParticipants: 1247,
    activeContests: (contestsData as any)?.contests?.filter((c: any) => c.status === 'active').length || 0,
    upcomingContests: (contestsData as any)?.contests?.filter((c: any) => c.status === 'upcoming').length || 0,
  };

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Contest Management</h1>
                <p className="text-gray-600">Create and manage coding contests for students</p>
              </div>
              <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
                <DialogTrigger asChild>
                  <Button>Create New Contest</Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Create New Contest</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSubmit(onSubmitContest)} className="space-y-4">
                    <div>
                      <Label htmlFor="title">Contest Title</Label>
                      <Input
                        id="title"
                        {...register("title", { required: "Title is required" })}
                        placeholder="Enter contest title"
                      />
                      {errors.title && (
                        <p className="text-sm text-red-600 mt-1">{errors.title.message as string}</p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        {...register("description", { required: "Description is required" })}
                        placeholder="Enter contest description"
                        rows={3}
                      />
                      {errors.description && (
                        <p className="text-sm text-red-600 mt-1">{errors.description.message as string}</p>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="startTime">Start Time</Label>
                        <Input
                          id="startTime"
                          type="datetime-local"
                          {...register("startTime", { required: "Start time is required" })}
                        />
                        {errors.startTime && (
                          <p className="text-sm text-red-600 mt-1">{errors.startTime.message as string}</p>
                        )}
                      </div>
                      
                      <div>
                        <Label htmlFor="endTime">End Time</Label>
                        <Input
                          id="endTime"
                          type="datetime-local"
                          {...register("endTime", { required: "End time is required" })}
                        />
                        {errors.endTime && (
                          <p className="text-sm text-red-600 mt-1">{errors.endTime.message as string}</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="duration">Duration (minutes)</Label>
                        <Input
                          id="duration"
                          type="number"
                          {...register("duration", { required: "Duration is required", min: 1 })}
                          placeholder="120"
                        />
                        {errors.duration && (
                          <p className="text-sm text-red-600 mt-1">{errors.duration.message as string}</p>
                        )}
                      </div>
                      
                      <div>
                        <Label htmlFor="maxParticipants">Max Participants (optional)</Label>
                        <Input
                          id="maxParticipants"
                          type="number"
                          {...register("maxParticipants", { min: 1 })}
                          placeholder="Leave empty for unlimited"
                        />
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setIsCreateModalOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createContestMutation.isPending}>
                        {createContestMutation.isPending ? "Creating..." : "Create Contest"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Stats Cards */}
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-brand-100 rounded-lg flex items-center justify-center">
                      <svg className="w-6 h-6 text-brand-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                      </svg>
                    </div>
                    <div className="ml-4">
                      <p className="text-2xl font-bold text-gray-900">{adminStats.totalContests}</p>
                      <p className="text-sm text-gray-500">Total Contests</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
                      <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"></path>
                      </svg>
                    </div>
                    <div className="ml-4">
                      <p className="text-2xl font-bold text-gray-900">{adminStats.totalParticipants}</p>
                      <p className="text-sm text-gray-500">Total Participants</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                      <svg className="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                      </svg>
                    </div>
                    <div className="ml-4">
                      <p className="text-2xl font-bold text-gray-900">{adminStats.activeContests}</p>
                      <p className="text-sm text-gray-500">Active Contests</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                      <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                      </svg>
                    </div>
                    <div className="ml-4">
                      <p className="text-2xl font-bold text-gray-900">{adminStats.upcomingContests}</p>
                      <p className="text-sm text-gray-500">Upcoming Contests</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contest List */}
            <Card>
              <CardContent className="p-6">
                <div className="border-b border-gray-200 pb-6 mb-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-gray-900">All Contests</h2>
                    <div className="flex items-center space-x-3">
                      <Select 
                        value={filters.status} 
                        onValueChange={(value) => handleFilterChange('status', value)}
                      >
                        <SelectTrigger className="w-40">
                          <SelectValue placeholder="All Status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Status</SelectItem>
                          <SelectItem value="upcoming">Upcoming</SelectItem>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input
                        type="search"
                        placeholder="Search contests..."
                        className="w-64"
                        value={filters.search}
                        onChange={(e) => handleFilterChange('search', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {contestsLoading ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600 mx-auto"></div>
                    </div>
                  ) : (contestsData as any)?.contests && (contestsData as any).contests.length > 0 ? (
                    (contestsData as any).contests.map((contest: any) => (
                      <div key={contest.id} className="p-6 border rounded-lg hover:bg-gray-50 transition-colors">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="font-semibold text-gray-900">{contest.title}</h3>
                              <Badge className={getStatusColor(contest.status)}>
                                {contest.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600 mb-3">{contest.description}</p>
                            <div className="grid grid-cols-4 gap-4 text-sm">
                              <div>
                                <span className="text-gray-500">Start:</span>
                                <span className="text-gray-900 ml-1">
                                  {new Date(contest.startTime).toLocaleDateString()} at{' '}
                                  {new Date(contest.startTime).toLocaleTimeString()}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">Duration:</span>
                                <span className="text-gray-900 ml-1">{contest.duration} minutes</span>
                              </div>
                              <div>
                                <span className="text-gray-500">Participants:</span>
                                <span className="text-gray-900 ml-1">
                                  {contest.maxParticipants ? `0/${contest.maxParticipants}` : '0'}
                                </span>
                              </div>
                              <div>
                                <span className="text-gray-500">Created:</span>
                                <span className="text-gray-900 ml-1">
                                  {new Date(contest.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 ml-6">
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="text-red-600 hover:text-red-700"
                              onClick={() => handleDeleteContest(contest.id, contest.title)}
                              disabled={deleteContestMutation.isPending}
                            >
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-12 text-gray-500">
                      <p>No contests found</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
