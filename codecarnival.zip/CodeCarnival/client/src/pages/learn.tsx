import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Learn() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: modules } = useQuery({
    queryKey: ["/api/learning/modules"],
    retry: false,
  });

  const { data: userProgress } = useQuery({
    queryKey: ["/api/learning/progress"],
    retry: false,
  });

  const updateProgressMutation = useMutation({
    mutationFn: async ({ moduleId, progress }: { moduleId: string; progress: any }) => {
      await apiRequest("PUT", `/api/learning/progress/${moduleId}`, progress);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/learning/progress"] });
      toast({
        title: "Progress Updated",
        description: "Your learning progress has been saved.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to update progress",
        variant: "destructive",
      });
    },
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-amber-100 text-amber-800';
      case 'hard':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressForModule = (moduleId: string) => {
    return userProgress?.find((p: any) => p.moduleId === moduleId);
  };

  const handleContinueModule = (moduleId: string) => {
    setLocation(`/learn/module/${moduleId}`);
  };

  // Group modules by programming language and topics
  const programmingLanguages = [
    {
      name: 'Python',
      modules: modules?.filter((m: any) => m.topics?.includes('python')) || [],
      color: 'bg-blue-100 text-blue-800',
      description: 'Versatile language for web development, data science, and automation'
    },
    {
      name: 'JavaScript',
      modules: modules?.filter((m: any) => m.topics?.includes('javascript')) || [],
      color: 'bg-yellow-100 text-yellow-800',
      description: 'Essential for web development, both frontend and backend'
    },
    {
      name: 'Java',
      modules: modules?.filter((m: any) => m.topics?.includes('java')) || [],
      color: 'bg-red-100 text-red-800',
      description: 'Enterprise applications and Android development'
    },
    {
      name: 'C++',
      modules: modules?.filter((m: any) => m.topics?.includes('cpp')) || [],
      color: 'bg-purple-100 text-purple-800',
      description: 'System programming and performance-critical applications'
    },
    {
      name: 'Go',
      modules: modules?.filter((m: any) => m.topics?.includes('go')) || [],
      color: 'bg-cyan-100 text-cyan-800',
      description: 'Modern language for cloud services and distributed systems'
    }
  ];

  const specialtyTopics = [
    {
      name: 'Data Structures & Algorithms',
      modules: modules?.filter((m: any) => 
        m.topics?.includes('data-structures') || m.topics?.includes('algorithms')
      ) || [],
      color: 'bg-green-100 text-green-800',
      description: 'Essential computer science concepts for problem solving'
    },
    {
      name: 'Machine Learning',
      modules: modules?.filter((m: any) => m.topics?.includes('machine-learning')) || [],
      color: 'bg-pink-100 text-pink-800',
      description: 'AI and data science fundamentals'
    },
    {
      name: 'Web Development',
      modules: modules?.filter((m: any) => 
        m.topics?.includes('web-development') || m.topics?.includes('frontend')
      ) || [],
      color: 'bg-indigo-100 text-indigo-800',
      description: 'Frontend and backend web technologies'
    },
    {
      name: 'Database & SQL',
      modules: modules?.filter((m: any) => 
        m.topics?.includes('sql') || m.topics?.includes('database-design')
      ) || [],
      color: 'bg-orange-100 text-orange-800',
      description: 'Database design and management'
    }
  ];

  const getPathProgress = (pathModules: any[]) => {
    if (!pathModules.length) return 0;
    const completedCount = pathModules.filter(module => {
      const progress = getProgressForModule(module.id);
      return progress?.isCompleted;
    }).length;
    return (completedCount / pathModules.length) * 100;
  };

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Learning Modules</h1>
              <p className="text-gray-600">Master programming concepts through structured learning paths</p>
            </div>

            {/* Programming Languages */}
            <div className="mb-12">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Programming Languages</h2>
              <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {programmingLanguages.filter(lang => lang.modules.length > 0).map((language) => (
                  <Card key={language.name}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-gray-900">{language.name}</h3>
                        <Badge className={language.color}>{language.modules.length} modules</Badge>
                      </div>
                      <p className="text-gray-600 mb-6 text-sm">{language.description}</p>
                      
                      <div className="space-y-3 mb-6">
                        {language.modules.slice(0, 2).map((module: any, index: number) => {
                          const progress = getProgressForModule(module.id);
                          const isCompleted = progress?.isCompleted;
                          
                          return (
                            <button
                              key={module.id} 
                              className={`w-full flex items-center justify-between p-3 rounded-lg border transition-colors hover:bg-opacity-75 ${
                                isCompleted ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                              }`}
                              onClick={() => handleContinueModule(module.id)}
                              data-testid={`button-module-${module.id}`}
                            >
                              <div className="flex items-center space-x-3">
                                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                                  isCompleted ? 'bg-green-500' : 'bg-blue-500'
                                }`}>
                                  {isCompleted ? (
                                    <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                                    </svg>
                                  ) : (
                                    <span className="text-white text-xs font-bold">{index + 1}</span>
                                  )}
                                </div>
                                <span className="text-sm font-medium text-gray-900">{module.title}</span>
                              </div>
                              <Badge className={getDifficultyColor(module.difficulty)}>
                                {module.difficulty}
                              </Badge>
                            </button>
                          );
                        })}
                        {language.modules.length > 2 && (
                          <div className="text-center text-sm text-gray-500">
                            +{language.modules.length - 2} more modules
                          </div>
                        )}
                      </div>

                      <div className="mb-4">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-600">Progress</span>
                          <span className="text-gray-900">{Math.round(getPathProgress(language.modules))}%</span>
                        </div>
                        <Progress value={getPathProgress(language.modules)} className="h-2" />
                      </div>

                      <Button 
                        className="w-full"
                        onClick={() => language.modules.length > 0 && handleContinueModule(language.modules[0].id)}
                        disabled={updateProgressMutation.isPending}
                      >
                        Start Learning
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Specialty Topics */}
            <div className="mb-12">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Specialty Topics</h2>
              <div className="grid lg:grid-cols-2 gap-6">
                {specialtyTopics.filter(topic => topic.modules.length > 0).map((topic) => (
                  <Card key={topic.name}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-gray-900">{topic.name}</h3>
                        <Badge className={topic.color}>{topic.modules.length} modules</Badge>
                      </div>
                      <p className="text-gray-600 mb-6 text-sm">{topic.description}</p>
                      
                      <div className="space-y-3 mb-6">
                        {topic.modules.slice(0, 3).map((module: any, index: number) => {
                          const progress = getProgressForModule(module.id);
                          const isCompleted = progress?.isCompleted;
                          
                          return (
                            <button
                              key={module.id} 
                              className={`w-full flex items-center justify-between p-3 rounded-lg border transition-colors hover:bg-opacity-75 ${
                                isCompleted ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                              }`}
                              onClick={() => handleContinueModule(module.id)}
                              data-testid={`button-module-${module.id}`}
                            >
                              <div className="flex items-center space-x-3">
                                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                                  isCompleted ? 'bg-green-500' : 'bg-purple-500'
                                }`}>
                                  {isCompleted ? (
                                    <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                                    </svg>
                                  ) : (
                                    <span className="text-white text-xs font-bold">{index + 1}</span>
                                  )}
                                </div>
                                <span className="text-sm font-medium text-gray-900">{module.title}</span>
                              </div>
                              <Badge className={getDifficultyColor(module.difficulty)}>
                                {module.difficulty}
                              </Badge>
                            </button>
                          );
                        })}
                      </div>

                      <div className="mb-4">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-600">Progress</span>
                          <span className="text-gray-900">{Math.round(getPathProgress(topic.modules))}%</span>
                        </div>
                        <Progress value={getPathProgress(topic.modules)} className="h-2" />
                      </div>

                      <Button 
                        className="w-full"
                        onClick={() => topic.modules.length > 0 && handleContinueModule(topic.modules[0].id)}
                        disabled={updateProgressMutation.isPending}
                      >
                        Start Learning
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* All Modules */}
            <div className="mb-12">
              <h2 className="text-xl font-bold text-gray-900 mb-6">All Learning Modules</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {modules?.map((module: any) => {
                  const progress = getProgressForModule(module.id);
                  const isCompleted = progress?.isCompleted;
                  
                  return (
                    <Card key={module.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <h4 className="font-medium text-gray-900 text-sm leading-tight">{module.title}</h4>
                          <div className="flex flex-col items-end space-y-1">
                            <Badge className={getDifficultyColor(module.difficulty)} variant="secondary">
                              {module.difficulty}
                            </Badge>
                            {isCompleted && (
                              <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                                <svg className="w-2 h-2 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path>
                                </svg>
                              </div>
                            )}
                          </div>
                        </div>
                        <p className="text-xs text-gray-600 mb-3 line-clamp-2">{module.description}</p>
                        <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                          <span>{module.estimatedHours}h estimated</span>
                          <span>{progress?.completedLessons || 0}/{module.content?.lessons?.length || 0} lessons</span>
                        </div>
                        <Button 
                          size="sm" 
                          className="w-full text-xs"
                          onClick={() => handleContinueModule(module.id)}
                          variant={isCompleted ? "outline" : "default"}
                        >
                          {isCompleted ? "Review" : "Start"}
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}