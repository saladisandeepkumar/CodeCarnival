import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Learn() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: modules } = useQuery({
    queryKey: ["/api/learning/modules"],
    retry: false,
  });

  const { data: userProgress } = useQuery({
    queryKey: ["/api/learning/progress"],
    retry: false,
  });

  const updateProgressMutation = useMutation({
    mutationFn: async ({ moduleId, progress }: { moduleId: string; progress: any }) => {
      await apiRequest("PUT", `/api/learning/progress/${moduleId}`, progress);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/learning/progress"] });
      toast({
        title: "Progress Updated",
        description: "Your learning progress has been saved.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to update progress",
        variant: "destructive",
      });
    },
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-amber-100 text-amber-800';
      case 'hard':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressForModule = (moduleId: string) => {
    return userProgress?.find((p: any) => p.moduleId === moduleId);
  };

  const handleContinueModule = (moduleId: string) => {
    setLocation(`/learn/module/${moduleId}`);
  };

  // Group modules by programming language and topics
  const programmingLanguages = [
    {
      name: 'Python',
      modules: modules?.filter((m: any) => m.topics?.includes('python')) || [],
      color: 'bg-blue-100 text-blue-800',
      description: 'Versatile language for web development, data science, and automation'
    },
    {
      name: 'JavaScript',
      modules: modules?.filter((m: any) => m.topics?.includes('javascript')) || [],
      color: 'bg-yellow-100 text-yellow-800',
      description: 'Essential for web development, both frontend and backend'
    },
    {
      name: 'Java',
      modules: modules?.filter((m: any) => m.topics?.includes('java')) || [],
      color: 'bg-red-100 text-red-800',
      description: 'Enterprise applications and Android development'
    },
    {
      name: 'C++',
      modules: modules?.filter((m: any) => m.topics?.includes('cpp')) || [],
      color: 'bg-purple-100 text-purple-800',
      description: 'System programming and performance-critical applications'
    },
    {
      name: 'Go',
      modules: modules?.filter((m: any) => m.topics?.includes('go')) || [],
      color: 'bg-cyan-100 text-cyan-800',
      description: 'Modern language for cloud services and distributed systems'
    }
  ];

  const specialtyTopics = [
    {
      name: 'Data Structures & Algorithms',
      modules: modules?.filter((m: any) => 
        m.topics?.includes('data-structures') || m.topics?.includes('algorithms')
      ) || [],
      color: 'bg-green-100 text-green-800',
      description: 'Essential computer science concepts for problem solving'
    },
    {
      name: 'Machine Learning',
      modules: modules?.filter((m: any) => m.topics?.includes('machine-learning')) || [],
      color: 'bg-pink-100 text-pink-800',
      description: 'AI and data science fundamentals'
    },
    {
      name: 'Web Development',
      modules: modules?.filter((m: any) => 
        m.topics?.includes('web-development') || m.topics?.includes('frontend')
      ) || [],
      color: 'bg-indigo-100 text-indigo-800',
      description: 'Frontend and backend web technologies'
    },
    {
      name: 'Database & SQL',
      modules: modules?.filter((m: any) => 
        m.topics?.includes('sql') || m.topics?.includes('database-design')
      ) || [],
      color: 'bg-orange-100 text-orange-800',
      description: 'Database design and management'
    }
  ];

  const getPathProgress = (pathModules: any[]) => {
    if (!pathModules.length) return 0;
    const completedCount = pathModules.filter(module => {
      const progress = getProgressForModule(module.id);
      return progress?.isCompleted;
    }).length;
    return (completedCount / pathModules.length) * 100;
  };

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Learning Modules</h1>
              <p className="text-gray-600">Master programming concepts through structured learning paths</p>
            </div>

            {/* Learning Paths */}
            <div className="grid lg:grid-cols-3 gap-8 mb-12">
              {/* Beginner Path */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">Beginner Path</h3>
                    <Badge className="bg-green-100 text-green-800">Beginner</Badge>
                  </div>
                  <p className="text-gray-600 mb-6">Start your programming journey with fundamental concepts and basic problem-solving techniques.</p>
                  
                  <div className="space-y-3 mb-6">
                    {beginnerModules.slice(0, 3).map((module: any, index: number) => {
                      const progress = getProgressForModule(module.id);
                      const isCompleted = progress?.isCompleted;
                      const isCurrent = index === 0 && !isCompleted; // First incomplete module
                      
                      return (
                        <button
                          key={module.id} 
                          className={`w-full flex items-center justify-between p-3 rounded-lg border transition-colors hover:bg-opacity-75 ${
                            isCompleted ? 'bg-green-50 border-green-200' : 
                            isCurrent ? 'bg-blue-50 border-blue-200' : 
                            'bg-gray-50 border-gray-200'
                          }`}
                          onClick={() => handleContinueModule(module.id)}
                          data-testid={`button-module-${module.id}`}
                        >
                          <div className="flex items-center space-x-3">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                              isCompleted ? 'bg-green-500' : 
                              isCurrent ? 'bg-blue-500' : 
                              'bg-gray-300'
                            }`}>
                              {isCompleted ? (
                                <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                                </svg>
                              ) : (
                                <span className="text-white text-xs font-bold">{index + 1}</span>
                              )}
                            </div>
                            <span className="text-sm font-medium text-gray-900">{module.title}</span>
                          </div>
                          <span className={`text-xs ${
                            isCompleted ? 'text-green-600' : 
                            isCurrent ? 'text-blue-600' : 
                            'text-gray-500'
                          }`}>
                            {isCompleted ? 'Completed' : isCurrent ? 'In Progress' : 'Locked'}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Progress</span>
                      <span className="text-gray-900">{Math.round(getPathProgress(beginnerModules))}/100%</span>
                    </div>
                    <Progress value={getPathProgress(beginnerModules)} className="h-2" />
                  </div>

                  <Button 
                    className="w-full"
                    onClick={() => beginnerModules.length > 0 && handleContinueModule(beginnerModules[0].id)}
                    disabled={updateProgressMutation.isPending}
                  >
                    {updateProgressMutation.isPending ? "Loading..." : "Continue Learning"}
                  </Button>
                </CardContent>
              </Card>

              {/* Intermediate Path */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">Intermediate Path</h3>
                    <Badge className="bg-amber-100 text-amber-800">Intermediate</Badge>
                  </div>
                  <p className="text-gray-600 mb-6">Dive deeper into algorithms, data structures, and advanced programming techniques.</p>
                  
                  <div className="space-y-3 mb-6">
                    {intermediateModules.slice(0, 3).map((module: any, index: number) => {
                      const progress = getProgressForModule(module.id);
                      const isCompleted = progress?.isCompleted;
                      const isLocked = getPathProgress(beginnerModules) < 80; // Unlock at 80% beginner completion
                      
                      return (
                        <div key={module.id} className={`flex items-center justify-between p-3 rounded-lg border ${
                          isCompleted ? 'bg-green-50 border-green-200' : 
                          'bg-gray-50 border-gray-200'
                        }`}>
                          <div className="flex items-center space-x-3">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                              isCompleted ? 'bg-green-500' : 'bg-gray-300'
                            }`}>
                              {isCompleted ? (
                                <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                                </svg>
                              ) : (
                                <span className="text-gray-600 text-xs font-bold">{index + 1}</span>
                              )}
                            </div>
                            <span className={`text-sm font-medium ${isLocked ? 'text-gray-500' : 'text-gray-900'}`}>
                              {module.title}
                            </span>
                          </div>
                          <span className="text-xs text-gray-500">
                            {isCompleted ? 'Completed' : 'Locked'}
                          </span>
                        </div>
                      );
                    })}
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Progress</span>
                      <span className="text-gray-900">{Math.round(getPathProgress(intermediateModules))}/100%</span>
                    </div>
                    <Progress value={getPathProgress(intermediateModules)} className="h-2" />
                  </div>

                  <Button 
                    className="w-full" 
                    variant="outline"
                    disabled={getPathProgress(beginnerModules) < 80}
                  >
                    Complete Beginner First
                  </Button>
                </CardContent>
              </Card>

              {/* Advanced Path */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">Advanced Path</h3>
                    <Badge className="bg-red-100 text-red-800">Advanced</Badge>
                  </div>
                  <p className="text-gray-600 mb-6">Master complex algorithms, system design, and competitive programming techniques.</p>
                  
                  <div className="space-y-3 mb-6">
                    {advancedModules.slice(0, 3).map((module: any, index: number) => {
                      const progress = getProgressForModule(module.id);
                      const isCompleted = progress?.isCompleted;
                      const isLocked = getPathProgress(intermediateModules) < 80;
                      
                      return (
                        <div key={module.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                          <div className="flex items-center space-x-3">
                            <div className="w-6 h-6 bg-gray-300 rounded-full flex items-center justify-center">
                              <span className="text-gray-600 text-xs font-bold">{index + 1}</span>
                            </div>
                            <span className="text-sm font-medium text-gray-500">{module.title}</span>
                          </div>
                          <span className="text-xs text-gray-500">Locked</span>
                        </div>
                      );
                    })}
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Progress</span>
                      <span className="text-gray-900">0/100%</span>
                    </div>
                    <Progress value={0} className="h-2" />
                  </div>

                  <Button 
                    className="w-full" 
                    variant="outline" 
                    disabled
                  >
                    Complete Intermediate First
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Technology-Specific Modules */}
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-6">Technology-Specific Modules</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Static technology modules for demo */}
                {[
                  { title: "JavaScript Fundamentals", description: "Master modern JavaScript ES6+ features and web development.", lessons: 15, hours: 8, icon: "💻" },
                  { title: "Python for Data Science", description: "Learn Python libraries for data analysis and machine learning.", lessons: 20, hours: 12, icon: "🐍" },
                  { title: "Database Design", description: "Learn SQL, database design principles, and optimization techniques.", lessons: 12, hours: 6, icon: "🗄️" },
                  { title: "React Development", description: "Build modern web applications with React and its ecosystem.", lessons: 18, hours: 10, icon: "⚛️" }
                ].map((tech, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-6">
                      <div className="text-2xl mb-4">{tech.icon}</div>
                      <h3 className="font-semibold text-gray-900 mb-2">{tech.title}</h3>
                      <p className="text-sm text-gray-600 mb-3">{tech.description}</p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{tech.lessons} lessons</span>
                        <span>~{tech.hours} hours</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
