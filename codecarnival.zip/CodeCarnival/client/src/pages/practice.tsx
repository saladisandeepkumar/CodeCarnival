import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

export default function Practice() {
  const [, setLocation] = useLocation();
  const [filters, setFilters] = useState({
    difficulty: "",
    language: "all",
    search: "",
    topics: [] as string[],
    page: 1
  });

  const { data: problemsData, isLoading } = useQuery({
    queryKey: ["/api/problems", filters],
    retry: false,
  });

  const difficulties = [
    { value: "easy", label: "Easy", count: 152 },
    { value: "medium", label: "Medium", count: 289 },
    { value: "hard", label: "Hard", count: 97 }
  ];

  const topics = [
    "arrays", "strings", "trees", "dynamic-programming", "graphs", 
    "sorting", "searching", "hash-tables", "linked-lists", "stacks-queues"
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-amber-100 text-amber-800';
      case 'hard':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleSolveProblem = (problemId: string) => {
    setLocation(`/problem/${problemId}`);
  };

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value,
      page: 1 // Reset page when filters change
    }));
  };

  const handleTopicToggle = (topic: string) => {
    setFilters(prev => ({
      ...prev,
      topics: prev.topics.includes(topic)
        ? prev.topics.filter(t => t !== topic)
        : [...prev.topics, topic],
      page: 1
    }));
  };

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="grid lg:grid-cols-4 gap-6">
            {/* Filters Sidebar */}
            <div className="lg:col-span-1">
              <Card className="sticky top-6">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-gray-900 mb-4">Filters</h3>
                  
                  {/* Difficulty */}
                  <div className="mb-6">
                    <Label className="block text-sm font-medium text-gray-700 mb-2">Difficulty</Label>
                    <div className="space-y-2">
                      {difficulties.map(diff => (
                        <label key={diff.value} className="flex items-center">
                          <Checkbox 
                            checked={filters.difficulty === diff.value}
                            onCheckedChange={(checked) => 
                              handleFilterChange('difficulty', checked ? diff.value : '')
                            }
                          />
                          <span className="ml-2 text-sm text-gray-700">{diff.label}</span>
                          <span className="ml-auto text-xs text-gray-500">{diff.count}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Language */}
                  <div className="mb-6">
                    <Label className="block text-sm font-medium text-gray-700 mb-2">Language</Label>
                    <Select value={filters.language} onValueChange={(value) => handleFilterChange('language', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Languages" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Languages</SelectItem>
                        <SelectItem value="python">Python</SelectItem>
                        <SelectItem value="javascript">JavaScript</SelectItem>
                        <SelectItem value="java">Java</SelectItem>
                        <SelectItem value="cpp">C++</SelectItem>
                        <SelectItem value="go">Go</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Topics */}
                  <div>
                    <Label className="block text-sm font-medium text-gray-700 mb-2">Topics</Label>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {topics.map(topic => (
                        <label key={topic} className="flex items-center">
                          <Checkbox 
                            checked={filters.topics.includes(topic)}
                            onCheckedChange={() => handleTopicToggle(topic)}
                          />
                          <span className="ml-2 text-sm text-gray-700 capitalize">
                            {topic.replace('-', ' ')}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Problems List */}
            <div className="lg:col-span-3">
              <Card>
                <CardContent className="p-6">
                  <div className="border-b border-gray-200 pb-6 mb-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-semibold text-gray-900">Practice Problems</h2>
                      <div className="flex items-center space-x-3">
                        <Input
                          type="search"
                          placeholder="Search problems..."
                          className="w-64"
                          value={filters.search}
                          onChange={(e) => handleFilterChange('search', e.target.value)}
                        />
                        <Select value="" onValueChange={() => {}}>
                          <SelectTrigger className="w-40">
                            <SelectValue placeholder="Sort by" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="newest">Newest</SelectItem>
                            <SelectItem value="difficulty">Difficulty</SelectItem>
                            <SelectItem value="acceptance">Acceptance Rate</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    {isLoading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600 mx-auto"></div>
                      </div>
                    ) : problemsData?.problems && problemsData.problems.length > 0 ? (
                      problemsData.problems.map((problem: any) => (
                        <div key={problem.id} className="p-6 hover:bg-gray-50 transition-colors border rounded-lg">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3 mb-2">
                                <h3 
                                  className="font-medium text-gray-900 hover:text-brand-600 cursor-pointer"
                                  onClick={() => handleSolveProblem(problem.id)}
                                >
                                  {problem.title}
                                </h3>
                                <Badge className={getDifficultyColor(problem.difficulty)}>
                                  {problem.difficulty}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 mb-3 line-clamp-2">{problem.description}</p>
                              <div className="flex items-center space-x-4 text-xs text-gray-500">
                                <span>{problem.acceptanceRate || 0}% acceptance</span>
                                <span>{problem.submissionCount || 0} submissions</span>
                                {problem.topics && problem.topics.length > 0 && (
                                  <div className="flex items-center space-x-1">
                                    <span>Topics:</span>
                                    {problem.topics.slice(0, 2).map((topic: string) => (
                                      <Badge key={topic} variant="secondary" className="text-xs">
                                        {topic}
                                      </Badge>
                                    ))}
                                    {problem.topics.length > 2 && (
                                      <span className="text-gray-400">+{problem.topics.length - 2} more</span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                            <Button 
                              className="ml-4"
                              onClick={() => handleSolveProblem(problem.id)}
                            >
                              Solve
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-12 text-gray-500">
                        <p>No problems found matching your criteria</p>
                      </div>
                    )}
                  </div>

                  {/* Pagination */}
                  {problemsData?.total && problemsData.total > 20 && (
                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-gray-700">
                          Showing {((filters.page - 1) * 20) + 1}-{Math.min(filters.page * 20, problemsData.total)} of {problemsData.total} problems
                        </p>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            disabled={filters.page === 1}
                            onClick={() => handleFilterChange('page', filters.page - 1)}
                          >
                            Previous
                          </Button>
                          <Button
                            variant="outline"
                            className="bg-brand-600 text-white"
                          >
                            {filters.page}
                          </Button>
                          <Button
                            variant="outline"
                            disabled={filters.page * 20 >= problemsData.total}
                            onClick={() => handleFilterChange('page', filters.page + 1)}
                          >
                            Next
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
