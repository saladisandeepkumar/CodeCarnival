import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { ChevronLeft, ChevronRight, CheckCircle, PlayCircle } from "lucide-react";

export default function ModuleDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentLessonIndex, setCurrentLessonIndex] = useState(0);

  const { data: module, isLoading: moduleLoading } = useQuery({
    queryKey: ["/api/learning/modules", id],
    retry: false,
  });

  const { data: userProgress } = useQuery({
    queryKey: ["/api/learning/progress"],
    retry: false,
  });

  const updateProgressMutation = useMutation({
    mutationFn: async ({ moduleId, progress }: { moduleId: string; progress: any }) => {
      await apiRequest("PUT", `/api/learning/progress/${moduleId}`, progress);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/learning/progress"] });
      toast({
        title: "Progress Updated",
        description: "Your learning progress has been saved.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to update progress",
        variant: "destructive",
      });
    },
  });

  if (moduleLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-brand-600"></div>
      </div>
    );
  }

  if (!module) {
    return (
      <div className="h-screen flex bg-gray-50">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header />
          <main className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Module Not Found</h1>
              <Button onClick={() => setLocation("/learn")}>
                Back to Learning
              </Button>
            </div>
          </main>
        </div>
      </div>
    );
  }

  const lessons = module.content?.lessons || [];
  const currentLesson = lessons[currentLessonIndex];
  
  const getProgressForModule = (moduleId: string) => {
    return userProgress?.find((p: any) => p.moduleId === moduleId);
  };

  const progress = getProgressForModule(id as string);
  const completedLessons = progress?.completedLessons || 0;
  const totalLessons = lessons.length;
  const progressPercentage = totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0;

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-amber-100 text-amber-800';
      case 'hard':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleCompleteLesson = () => {
    const newCompletedLessons = Math.max(completedLessons, currentLessonIndex + 1);
    const isCompleted = newCompletedLessons >= totalLessons;
    
    updateProgressMutation.mutate({
      moduleId: id as string,
      progress: {
        completedLessons: newCompletedLessons,
        totalLessons,
        isCompleted
      }
    });
  };

  const canAccessLesson = (lessonIndex: number) => {
    return lessonIndex <= completedLessons;
  };

  const isLessonCompleted = (lessonIndex: number) => {
    return lessonIndex < completedLessons;
  };

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto">
          {/* Header Section */}
          <div className="bg-white border-b border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setLocation("/learn")}
                  data-testid="button-back-to-learn"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  Back to Learning
                </Button>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900" data-testid="text-module-title">
                    {module.title}
                  </h1>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge className={getDifficultyColor(module.difficulty)}>
                      {module.difficulty}
                    </Badge>
                    <span className="text-sm text-gray-500">
                      {module.estimatedHours}h estimated
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-500 mb-1">Progress</div>
                <div className="font-semibold text-gray-900">
                  {completedLessons}/{totalLessons} lessons
                </div>
                <Progress value={progressPercentage} className="w-32 mt-1" />
              </div>
            </div>
          </div>

          <div className="flex flex-1">
            {/* Lesson Sidebar */}
            <div className="w-80 bg-white border-r border-gray-200 overflow-y-auto">
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-3">Lessons</h3>
                <div className="space-y-2">
                  {lessons.map((lesson: any, index: number) => (
                    <button
                      key={index}
                      onClick={() => canAccessLesson(index) && setCurrentLessonIndex(index)}
                      disabled={!canAccessLesson(index)}
                      className={`w-full text-left p-3 rounded-lg border transition-colors ${
                        currentLessonIndex === index
                          ? 'bg-brand-50 border-brand-200 text-brand-900'
                          : canAccessLesson(index)
                          ? 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                          : 'bg-gray-25 border-gray-100 text-gray-400 cursor-not-allowed'
                      }`}
                      data-testid={`button-lesson-${index}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {isLessonCompleted(index) ? (
                            <CheckCircle className="w-4 h-4 text-green-500" />
                          ) : canAccessLesson(index) ? (
                            <PlayCircle className="w-4 h-4 text-brand-500" />
                          ) : (
                            <div className="w-4 h-4 rounded-full bg-gray-300" />
                          )}
                          <span className="font-medium text-sm">{lesson.title}</span>
                        </div>
                        <span className="text-xs text-gray-500">{lesson.duration}min</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 overflow-y-auto">
              {currentLesson ? (
                <div className="p-8">
                  <div className="max-w-4xl mx-auto">
                    <div className="mb-6">
                      <h2 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-lesson-title">
                        {currentLesson.title}
                      </h2>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>Lesson {currentLessonIndex + 1} of {totalLessons}</span>
                        <span>•</span>
                        <span>{currentLesson.duration} minutes</span>
                      </div>
                    </div>

                    <Card>
                      <CardContent className="p-8">
                        <div className="prose max-w-none" data-testid="text-lesson-content">
                          <p>{currentLesson.content}</p>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-between mt-8">
                      <Button
                        variant="outline"
                        onClick={() => setCurrentLessonIndex(Math.max(0, currentLessonIndex - 1))}
                        disabled={currentLessonIndex === 0}
                        data-testid="button-previous-lesson"
                      >
                        <ChevronLeft className="w-4 h-4 mr-1" />
                        Previous
                      </Button>

                      <div className="flex items-center space-x-3">
                        {!isLessonCompleted(currentLessonIndex) && (
                          <Button
                            onClick={handleCompleteLesson}
                            disabled={updateProgressMutation.isPending}
                            data-testid="button-complete-lesson"
                          >
                            {updateProgressMutation.isPending ? "Saving..." : "Complete Lesson"}
                          </Button>
                        )}
                        
                        <Button
                          variant={currentLessonIndex === totalLessons - 1 ? "default" : "outline"}
                          onClick={() => {
                            if (currentLessonIndex < totalLessons - 1) {
                              setCurrentLessonIndex(currentLessonIndex + 1);
                            } else {
                              setLocation("/learn");
                            }
                          }}
                          disabled={currentLessonIndex === totalLessons - 1 && !canAccessLesson(currentLessonIndex + 1)}
                          data-testid="button-next-lesson"
                        >
                          {currentLessonIndex === totalLessons - 1 ? "Back to Learning" : "Next"}
                          {currentLessonIndex < totalLessons - 1 && <ChevronRight className="w-4 h-4 ml-1" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No lessons available</h3>
                    <p className="text-gray-500">This module doesn't have any lessons yet.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}