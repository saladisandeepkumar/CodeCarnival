import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Profile() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState("activity");

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: userStats } = useQuery({
    queryKey: ["/api/users/me/stats"],
    retry: false,
  });

  const { data: recentActivity } = useQuery({
    queryKey: ["/api/users/me/activity", { limit: 20 }],
    retry: false,
  });

  const { data: userContests } = useQuery({
    queryKey: ["/api/users/me/contests"],
    retry: false,
  });

  const { data: submissions } = useQuery({
    queryKey: ["/api/submissions/me", { limit: 20 }],
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-brand-600"></div>
      </div>
    );
  }

  const getActivityIcon = (type: string, status?: string) => {
    if (type === 'submission' && status === 'accepted') {
      return (
        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
          <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
          </svg>
        </div>
      );
    }
    if (type === 'module') {
      return (
        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
          <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
          </svg>
        </div>
      );
    }
    return (
      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
        <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
        </svg>
      </div>
    );
  };

  const getSubmissionStatusColor = (status: string) => {
    switch (status) {
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'wrong_answer':
        return 'bg-red-100 text-red-800';
      case 'time_limit_exceeded':
        return 'bg-yellow-100 text-yellow-800';
      case 'compilation_error':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Less than an hour ago';
    } else if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays} days ago`;
    }
  };

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto">
            {/* Profile Header */}
            <Card className="mb-6">
              <CardContent className="p-8">
                <div className="flex items-center space-x-6">
                  <img 
                    src={user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=128&h=128"} 
                    alt="Profile" 
                    className="w-32 h-32 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                      {user?.firstName && user?.lastName 
                        ? `${user.firstName} ${user.lastName}` 
                        : user?.email?.split('@')[0] || 'User'}
                    </h1>
                    <p className="text-gray-600 mb-4">
                      {user?.role === 'admin' ? 'Administrator' : 'Student'} at Code Carnival
                    </p>
                    <div className="flex items-center space-x-6 text-sm text-gray-500">
                      <div className="flex items-center">
                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z"></path>
                        </svg>
                        <span>{userStats?.streak || 0} day streak</span>
                      </div>
                      <div className="flex items-center">
                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                        </svg>
                        <span>Joined {new Date(user?.createdAt || '').toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center">
                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                        </svg>
                        <span>{user?.email}</span>
                      </div>
                    </div>
                  </div>
                  <Button>Edit Profile</Button>
                </div>
              </CardContent>
            </Card>

            {/* Stats Grid */}
            <div className="grid md:grid-cols-4 gap-6 mb-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-brand-600 mb-2">{userStats?.problemsSolved || 0}</div>
                  <div className="text-sm text-gray-600">Problems Solved</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-2">{userStats?.contestsJoined || 0}</div>
                  <div className="text-sm text-gray-600">Contests Joined</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-amber-600 mb-2">{userStats?.rating || 1200}</div>
                  <div className="text-sm text-gray-600">Rating</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-emerald-600 mb-2">{userStats?.modulesCompleted || 0}</div>
                  <div className="text-sm text-gray-600">Modules Completed</div>
                </CardContent>
              </Card>
            </div>

            {/* Tabs */}
            <Card>
              <div className="border-b border-gray-200">
                <nav className="flex space-x-8 px-6">
                  {[
                    { id: "activity", name: "Recent Activity" },
                    { id: "submissions", name: "Submissions" },
                    { id: "contests", name: "Contests" },
                    { id: "progress", name: "Progress" },
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`py-4 border-b-2 font-medium text-sm ${
                        activeTab === tab.id
                          ? "border-brand-600 text-brand-600"
                          : "border-transparent text-gray-500 hover:text-gray-700"
                      }`}
                    >
                      {tab.name}
                    </button>
                  ))}
                </nav>
              </div>

              <CardContent className="p-6">
                {/* Recent Activity Tab */}
                {activeTab === "activity" && (
                  <div className="space-y-4">
                    {recentActivity && recentActivity.length > 0 ? (
                      recentActivity.map((activity: any, index: number) => (
                        <div key={index} className="flex items-center justify-between py-4 border-b border-gray-100 last:border-b-0">
                          <div className="flex items-center space-x-3">
                            {getActivityIcon(activity.type, activity.status)}
                            <div>
                              <p className="font-medium text-gray-900">
                                {activity.type === 'submission' ? `Solved "${activity.title}"` : `Completed "${activity.title}"`}
                              </p>
                              <p className="text-sm text-gray-500">
                                {formatDate(activity.time)} • {activity.difficulty} difficulty
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            {activity.points > 0 && (
                              <>
                                <span className="text-green-600 font-medium">+{activity.points} pts</span>
                                <p className="text-xs text-gray-500">First attempt</p>
                              </>
                            )}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <p>No recent activity</p>
                      </div>
                    )}
                  </div>
                )}

                {/* Submissions Tab */}
                {activeTab === "submissions" && (
                  <div className="space-y-4">
                    {submissions && submissions.length > 0 ? (
                      submissions.map((submission: any) => (
                        <div key={submission.id} className="flex items-center justify-between py-4 border-b border-gray-100 last:border-b-0">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h4 className="font-medium text-gray-900">Problem Submission</h4>
                              <Badge className={getSubmissionStatusColor(submission.status)}>
                                {submission.status.replace('_', ' ')}
                              </Badge>
                              <Badge variant="outline">{submission.language}</Badge>
                            </div>
                            <div className="text-sm text-gray-500">
                              <span>Submitted {formatDate(submission.submittedAt)}</span>
                              {submission.runtime && (
                                <span className="ml-4">Runtime: {submission.runtime}ms</span>
                              )}
                              {submission.testCasesPassed !== undefined && (
                                <span className="ml-4">
                                  Tests: {submission.testCasesPassed}/{submission.totalTestCases}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <p>No submissions yet</p>
                      </div>
                    )}
                  </div>
                )}

                {/* Contests Tab */}
                {activeTab === "contests" && (
                  <div className="space-y-4">
                    {userContests && userContests.length > 0 ? (
                      userContests.map((participation: any) => (
                        <div key={participation.id} className="flex items-center justify-between py-4 border-b border-gray-100 last:border-b-0">
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{participation.contest.title}</h4>
                            <p className="text-sm text-gray-500 mb-2">{participation.contest.description}</p>
                            <div className="text-xs text-gray-500">
                              <span>Registered {formatDate(participation.registeredAt)}</span>
                              {participation.rank && (
                                <span className="ml-4">Rank: #{participation.rank}</span>
                              )}
                              {participation.score !== undefined && (
                                <span className="ml-4">Score: {participation.score}</span>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge className={
                              participation.contest.status === 'completed' ? 'bg-gray-100 text-gray-800' :
                              participation.contest.status === 'active' ? 'bg-green-100 text-green-800' :
                              'bg-blue-100 text-blue-800'
                            }>
                              {participation.contest.status}
                            </Badge>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <p>No contest participations yet</p>
                      </div>
                    )}
                  </div>
                )}

                {/* Progress Tab */}
                {activeTab === "progress" && (
                  <div className="text-center py-8 text-gray-500">
                    <p>Progress tracking coming soon</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
