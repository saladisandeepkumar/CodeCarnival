import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("user"), // 'user' or 'admin'
  streak: integer("streak").default(0),
  lastSolvedDate: timestamp("last_solved_date"),
  rating: integer("rating").default(1200),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Enums
export const difficultyEnum = pgEnum("difficulty", ["easy", "medium", "hard"]);
export const languageEnum = pgEnum("language", ["python", "javascript", "java", "cpp", "go", "c", "csharp"]);
export const problemStatusEnum = pgEnum("problem_status", ["draft", "published", "archived"]);
export const contestStatusEnum = pgEnum("contest_status", ["upcoming", "active", "completed"]);
export const submissionStatusEnum = pgEnum("submission_status", ["pending", "accepted", "wrong_answer", "time_limit_exceeded", "compilation_error"]);

// Problems table
export const problems = pgTable("problems", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  difficulty: difficultyEnum("difficulty").notNull(),
  topics: text("topics").array().default([]), // Array of topic strings
  testCases: jsonb("test_cases").notNull(), // JSON array of test cases
  starterCode: jsonb("starter_code").notNull(), // Object with code for each language
  solution: jsonb("solution"), // Object with solution for each language
  acceptanceRate: integer("acceptance_rate").default(0),
  submissionCount: integer("submission_count").default(0),
  status: problemStatusEnum("status").default("draft"),
  isProblemOfDay: boolean("is_problem_of_day").default(false),
  problemOfDayDate: timestamp("problem_of_day_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Contests table
export const contests = pgTable("contests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  duration: integer("duration").notNull(), // Duration in minutes
  maxParticipants: integer("max_participants"),
  status: contestStatusEnum("status").default("upcoming"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Contest Problems relationship table
export const contestProblems = pgTable("contest_problems", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  contestId: varchar("contest_id").references(() => contests.id),
  problemId: varchar("problem_id").references(() => problems.id),
  points: integer("points").default(100),
  order: integer("order").notNull(),
});

// User submissions
export const submissions = pgTable("submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  problemId: varchar("problem_id").references(() => problems.id),
  contestId: varchar("contest_id").references(() => contests.id), // Optional - null for practice problems
  language: languageEnum("language").notNull(),
  code: text("code").notNull(),
  status: submissionStatusEnum("status").default("pending"),
  runtime: integer("runtime"), // Runtime in milliseconds
  memory: integer("memory"), // Memory usage in KB
  testCasesPassed: integer("test_cases_passed").default(0),
  totalTestCases: integer("total_test_cases").default(0),
  errorMessage: text("error_message"),
  submittedAt: timestamp("submitted_at").defaultNow(),
});

// Learning modules
export const learningModules = pgTable("learning_modules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  content: jsonb("content").notNull(), // Rich content with lessons
  difficulty: difficultyEnum("difficulty").notNull(),
  estimatedHours: integer("estimated_hours").default(1),
  prerequisites: text("prerequisites").array().default([]), // Array of module IDs
  topics: text("topics").array().default([]), // Array of topic strings
  order: integer("order").notNull(),
  isPublished: boolean("is_published").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User progress in learning modules
export const userProgress = pgTable("user_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  moduleId: varchar("module_id").references(() => learningModules.id),
  completedLessons: integer("completed_lessons").default(0),
  totalLessons: integer("total_lessons").default(0),
  isCompleted: boolean("is_completed").default(false),
  completedAt: timestamp("completed_at"),
  startedAt: timestamp("started_at").defaultNow(),
});

// Contest participations
export const contestParticipations = pgTable("contest_participations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  contestId: varchar("contest_id").references(() => contests.id),
  rank: integer("rank"),
  score: integer("score").default(0),
  registeredAt: timestamp("registered_at").defaultNow(),
  finishedAt: timestamp("finished_at"),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  submissions: many(submissions),
  contestsCreated: many(contests),
  contestParticipations: many(contestParticipations),
  userProgress: many(userProgress),
}));

export const problemsRelations = relations(problems, ({ many }) => ({
  submissions: many(submissions),
  contestProblems: many(contestProblems),
}));

export const contestsRelations = relations(contests, ({ one, many }) => ({
  createdBy: one(users, {
    fields: [contests.createdBy],
    references: [users.id],
  }),
  contestProblems: many(contestProblems),
  participations: many(contestParticipations),
}));

export const contestProblemsRelations = relations(contestProblems, ({ one }) => ({
  contest: one(contests, {
    fields: [contestProblems.contestId],
    references: [contests.id],
  }),
  problem: one(problems, {
    fields: [contestProblems.problemId],
    references: [problems.id],
  }),
}));

export const submissionsRelations = relations(submissions, ({ one }) => ({
  user: one(users, {
    fields: [submissions.userId],
    references: [users.id],
  }),
  problem: one(problems, {
    fields: [submissions.problemId],
    references: [problems.id],
  }),
  contest: one(contests, {
    fields: [submissions.contestId],
    references: [contests.id],
  }),
}));

export const learningModulesRelations = relations(learningModules, ({ many }) => ({
  userProgress: many(userProgress),
}));

export const userProgressRelations = relations(userProgress, ({ one }) => ({
  user: one(users, {
    fields: [userProgress.userId],
    references: [users.id],
  }),
  module: one(learningModules, {
    fields: [userProgress.moduleId],
    references: [learningModules.id],
  }),
}));

export const contestParticipationsRelations = relations(contestParticipations, ({ one }) => ({
  user: one(users, {
    fields: [contestParticipations.userId],
    references: [users.id],
  }),
  contest: one(contests, {
    fields: [contestParticipations.contestId],
    references: [contests.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProblemSchema = createInsertSchema(problems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  acceptanceRate: true,
  submissionCount: true,
});

export const insertContestSchema = createInsertSchema(contests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSubmissionSchema = createInsertSchema(submissions).omit({
  id: true,
  submittedAt: true,
});

export const insertLearningModuleSchema = createInsertSchema(learningModules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserProgressSchema = createInsertSchema(userProgress).omit({
  id: true,
  startedAt: true,
});

export const insertContestParticipationSchema = createInsertSchema(contestParticipations).omit({
  id: true,
  registeredAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertProblem = z.infer<typeof insertProblemSchema>;
export type Problem = typeof problems.$inferSelect;
export type InsertContest = z.infer<typeof insertContestSchema>;
export type Contest = typeof contests.$inferSelect;
export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type Submission = typeof submissions.$inferSelect;
export type InsertLearningModule = z.infer<typeof insertLearningModuleSchema>;
export type LearningModule = typeof learningModules.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type UserProgress = typeof userProgress.$inferSelect;
export type InsertContestParticipation = z.infer<typeof insertContestParticipationSchema>;
export type ContestParticipation = typeof contestParticipations.$inferSelect;
export type ContestProblem = typeof contestProblems.$inferSelect;
