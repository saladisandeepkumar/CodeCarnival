import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, isAdmin } from "./replitAuth";
import { insertProblemSchema, insertContestSchema, insertSubmissionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Problem routes
  app.get('/api/problems', async (req, res) => {
    try {
      const {
        difficulty,
        topics,
        search,
        language,
        page = 1,
        limit = 20
      } = req.query;

      const offset = (Number(page) - 1) * Number(limit);
      const topicsArray = topics ? (Array.isArray(topics) ? topics : [topics]) : undefined;

      const result = await storage.getProblems({
        difficulty: difficulty as string,
        topics: topicsArray as string[],
        search: search as string,
        language: language as string,
        limit: Number(limit),
        offset
      });

      res.json(result);
    } catch (error) {
      console.error("Error fetching problems:", error);
      res.status(500).json({ message: "Failed to fetch problems" });
    }
  });

  app.get('/api/problems/daily', async (req, res) => {
    try {
      const problem = await storage.getProblemOfTheDay();
      if (!problem) {
        return res.status(404).json({ message: "No problem of the day set" });
      }
      res.json(problem);
    } catch (error) {
      console.error("Error fetching problem of the day:", error);
      res.status(500).json({ message: "Failed to fetch problem of the day" });
    }
  });

  app.get('/api/problems/:id', async (req, res) => {
    try {
      const problem = await storage.getProblem(req.params.id);
      if (!problem) {
        return res.status(404).json({ message: "Problem not found" });
      }
      res.json(problem);
    } catch (error) {
      console.error("Error fetching problem:", error);
      res.status(500).json({ message: "Failed to fetch problem" });
    }
  });

  // Admin-only problem management
  app.post('/api/problems', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const problemData = insertProblemSchema.parse(req.body);
      const problem = await storage.createProblem(problemData);
      res.status(201).json(problem);
    } catch (error) {
      console.error("Error creating problem:", error);
      res.status(500).json({ message: "Failed to create problem" });
    }
  });

  app.put('/api/problems/:id', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const problemData = insertProblemSchema.partial().parse(req.body);
      const problem = await storage.updateProblem(req.params.id, problemData);
      res.json(problem);
    } catch (error) {
      console.error("Error updating problem:", error);
      res.status(500).json({ message: "Failed to update problem" });
    }
  });

  app.post('/api/problems/:id/daily', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      await storage.setProblemOfTheDay(req.params.id);
      res.json({ message: "Problem of the day set successfully" });
    } catch (error) {
      console.error("Error setting problem of the day:", error);
      res.status(500).json({ message: "Failed to set problem of the day" });
    }
  });

  // Contest routes
  app.get('/api/contests', async (req, res) => {
    try {
      const {
        status,
        search,
        page = 1,
        limit = 20
      } = req.query;

      const offset = (Number(page) - 1) * Number(limit);

      const result = await storage.getContests({
        status: status as string,
        search: search as string,
        limit: Number(limit),
        offset
      });

      res.json(result);
    } catch (error) {
      console.error("Error fetching contests:", error);
      res.status(500).json({ message: "Failed to fetch contests" });
    }
  });

  app.get('/api/contests/:id', async (req, res) => {
    try {
      const contest = await storage.getContest(req.params.id);
      if (!contest) {
        return res.status(404).json({ message: "Contest not found" });
      }
      res.json(contest);
    } catch (error) {
      console.error("Error fetching contest:", error);
      res.status(500).json({ message: "Failed to fetch contest" });
    }
  });

  app.get('/api/contests/:id/problems', async (req, res) => {
    try {
      const problems = await storage.getContestProblems(req.params.id);
      res.json(problems);
    } catch (error) {
      console.error("Error fetching contest problems:", error);
      res.status(500).json({ message: "Failed to fetch contest problems" });
    }
  });

  // Admin-only contest management
  app.post('/api/contests', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Convert string dates to Date objects
      const processedBody = {
        ...req.body,
        startTime: req.body.startTime ? new Date(req.body.startTime) : undefined,
        endTime: req.body.endTime ? new Date(req.body.endTime) : undefined,
        createdBy: userId
      };
      
      const contestData = insertContestSchema.parse(processedBody);
      const contest = await storage.createContest(contestData);
      res.status(201).json(contest);
    } catch (error) {
      console.error("Error creating contest:", error);
      res.status(500).json({ message: "Failed to create contest" });
    }
  });

  app.put('/api/contests/:id', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      // Convert string dates to Date objects  
      const processedBody = {
        ...req.body,
        startTime: req.body.startTime ? new Date(req.body.startTime) : undefined,
        endTime: req.body.endTime ? new Date(req.body.endTime) : undefined,
      };
      
      const contestData = insertContestSchema.partial().parse(processedBody);
      const contest = await storage.updateContest(req.params.id, contestData);
      res.json(contest);
    } catch (error) {
      console.error("Error updating contest:", error);
      res.status(500).json({ message: "Failed to update contest" });
    }
  });

  app.delete('/api/contests/:id', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      await storage.deleteContest(req.params.id);
      res.json({ message: "Contest deleted successfully" });
    } catch (error) {
      console.error("Error deleting contest:", error);
      res.status(500).json({ message: "Failed to delete contest" });
    }
  });

  // Admin-only: Add problem to contest
  app.post('/api/contests/:id/problems', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const { problemId, points = 100, order } = req.body;
      const contestId = req.params.id;
      
      await storage.addProblemToContest(contestId, problemId, points, order);
      res.json({ message: "Problem added to contest successfully" });
    } catch (error) {
      console.error("Error adding problem to contest:", error);
      res.status(500).json({ message: "Failed to add problem to contest" });
    }
  });

  // Contest participation
  app.post('/api/contests/:id/register', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const contestId = req.params.id;

      // Check if already registered
      const existing = await storage.getContestParticipation(userId, contestId);
      if (existing) {
        return res.status(400).json({ message: "Already registered for this contest" });
      }

      const participation = await storage.registerForContest(userId, contestId);
      res.status(201).json(participation);
    } catch (error) {
      console.error("Error registering for contest:", error);
      res.status(500).json({ message: "Failed to register for contest" });
    }
  });

  // Submission routes
  app.post('/api/submissions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const submissionData = insertSubmissionSchema.parse({
        ...req.body,
        userId
      });

      const submission = await storage.createSubmission(submissionData);
      
      // Here you would typically execute the code and update the submission
      // For now, we'll just mark it as pending
      res.status(201).json(submission);
    } catch (error) {
      console.error("Error creating submission:", error);
      res.status(500).json({ message: "Failed to create submission" });
    }
  });

  app.get('/api/submissions/me', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { limit = 50 } = req.query;
      
      const submissions = await storage.getUserSubmissions(userId, Number(limit));
      res.json(submissions);
    } catch (error) {
      console.error("Error fetching user submissions:", error);
      res.status(500).json({ message: "Failed to fetch submissions" });
    }
  });

  // Learning routes
  app.get('/api/learning/modules', async (req, res) => {
    try {
      const { difficulty } = req.query;
      const modules = await storage.getLearningModules(difficulty as string);
      res.json(modules);
    } catch (error) {
      console.error("Error fetching learning modules:", error);
      res.status(500).json({ message: "Failed to fetch learning modules" });
    }
  });

  app.get('/api/learning/modules/:id', async (req, res) => {
    try {
      const module = await storage.getLearningModule(req.params.id);
      if (!module) {
        return res.status(404).json({ message: "Learning module not found" });
      }
      res.json(module);
    } catch (error) {
      console.error("Error fetching learning module:", error);
      res.status(500).json({ message: "Failed to fetch learning module" });
    }
  });

  app.get('/api/learning/progress', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching user progress:", error);
      res.status(500).json({ message: "Failed to fetch user progress" });
    }
  });

  app.put('/api/learning/progress/:moduleId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const moduleId = req.params.moduleId;
      
      const progressSchema = z.object({
        completedLessons: z.number().optional(),
        totalLessons: z.number().optional(),
        isCompleted: z.boolean().optional(),
      });
      
      const progressData = progressSchema.parse(req.body);
      const updateData: any = { ...progressData };
      if (progressData.isCompleted) {
        updateData.completedAt = new Date();
      }
      
      const progress = await storage.updateUserProgress(userId, moduleId, updateData);
      res.json(progress);
    } catch (error) {
      console.error("Error updating user progress:", error);
      res.status(500).json({ message: "Failed to update user progress" });
    }
  });

  // User stats and activity
  app.get('/api/users/me/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  app.get('/api/users/me/activity', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { limit = 10 } = req.query;
      
      const activity = await storage.getUserRecentActivity(userId, Number(limit));
      res.json(activity);
    } catch (error) {
      console.error("Error fetching user activity:", error);
      res.status(500).json({ message: "Failed to fetch user activity" });
    }
  });

  app.get('/api/users/me/contests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const participations = await storage.getUserContestParticipations(userId);
      res.json(participations);
    } catch (error) {
      console.error("Error fetching user contests:", error);
      res.status(500).json({ message: "Failed to fetch user contests" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
