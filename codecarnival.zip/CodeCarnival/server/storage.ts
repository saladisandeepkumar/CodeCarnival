import {
  users,
  problems,
  contests,
  contestProblems,
  submissions,
  learningModules,
  userProgress,
  contestParticipations,
  type User,
  type UpsertUser,
  type Problem,
  type InsertProblem,
  type Contest,
  type InsertContest,
  type Submission,
  type InsertSubmission,
  type LearningModule,
  type InsertLearningModule,
  type UserProgress,
  type InsertUserProgress,
  type ContestParticipation,
  type InsertContestParticipation,
  type ContestProblem,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, sql, count, avg, or, like, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Problem operations
  getProblems(filters?: {
    difficulty?: string;
    topics?: string[];
    search?: string;
    language?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ problems: Problem[]; total: number }>;
  getProblem(id: string): Promise<Problem | undefined>;
  createProblem(problem: InsertProblem): Promise<Problem>;
  updateProblem(id: string, problem: Partial<InsertProblem>): Promise<Problem>;
  deleteProblem(id: string): Promise<void>;
  getProblemOfTheDay(): Promise<Problem | undefined>;
  setProblemOfTheDay(problemId: string): Promise<void>;
  
  // Contest operations
  getContests(filters?: {
    status?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ contests: Contest[]; total: number }>;
  getContest(id: string): Promise<Contest | undefined>;
  createContest(contest: InsertContest): Promise<Contest>;
  updateContest(id: string, contest: Partial<InsertContest>): Promise<Contest>;
  deleteContest(id: string): Promise<void>;
  getContestProblems(contestId: string): Promise<(ContestProblem & { problem: Problem })[]>;
  addProblemToContest(contestId: string, problemId: string, points: number, order: number): Promise<void>;
  
  // Submission operations
  createSubmission(submission: InsertSubmission): Promise<Submission>;
  getSubmission(id: string): Promise<Submission | undefined>;
  updateSubmission(id: string, updates: Partial<Submission>): Promise<Submission>;
  getUserSubmissions(userId: string, limit?: number): Promise<Submission[]>;
  getProblemSubmissions(problemId: string, userId: string): Promise<Submission[]>;
  
  // Learning operations
  getLearningModules(difficulty?: string): Promise<LearningModule[]>;
  getLearningModule(id: string): Promise<LearningModule | undefined>;
  createLearningModule(module: InsertLearningModule): Promise<LearningModule>;
  updateLearningModule(id: string, module: Partial<InsertLearningModule>): Promise<LearningModule>;
  getUserProgress(userId: string): Promise<(UserProgress & { module: LearningModule })[]>;
  updateUserProgress(userId: string, moduleId: string, progress: Partial<InsertUserProgress>): Promise<UserProgress>;
  
  // Contest participation
  registerForContest(userId: string, contestId: string): Promise<ContestParticipation>;
  getContestParticipation(userId: string, contestId: string): Promise<ContestParticipation | undefined>;
  getUserContestParticipations(userId: string): Promise<(ContestParticipation & { contest: Contest })[]>;
  
  // Statistics
  getUserStats(userId: string): Promise<{
    problemsSolved: number;
    contestsJoined: number;
    rating: number;
    modulesCompleted: number;
    streak: number;
    weeklyProgress: number;
  }>;
  
  // Recent activity
  getUserRecentActivity(userId: string, limit?: number): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.email,
        set: {
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Problem operations
  async getProblems(filters?: {
    difficulty?: string;
    topics?: string[];
    search?: string;
    language?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ problems: Problem[]; total: number }> {
    const conditions = [eq(problems.status, "published")];
    
    if (filters?.difficulty && filters.difficulty !== "") {
      conditions.push(eq(problems.difficulty, filters.difficulty as any));
    }
    
    if (filters?.search) {
      conditions.push(
        or(
          like(problems.title, `%${filters.search}%`),
          like(problems.description, `%${filters.search}%`)
        )!
      );
    }
    
    if (filters?.topics && filters.topics.length > 0) {
      // Use PostgreSQL array overlap operator
      conditions.push(sql`${problems.topics} && ${filters.topics}`);
    }
    
    const whereCondition = conditions.length > 0 ? and(...conditions) : undefined;
    
    let query = db.select().from(problems);
    let countQuery = db.select({ count: count() }).from(problems);
    
    if (whereCondition) {
      query = query.where(whereCondition);
      countQuery = countQuery.where(whereCondition);
    }
    
    query = query.orderBy(desc(problems.createdAt));
    
    if (filters?.limit) {
      query = query.limit(filters.limit);
    }
    
    if (filters?.offset) {
      query = query.offset(filters.offset);
    }
    
    const [problemResults, countResults] = await Promise.all([
      query,
      countQuery
    ]);
    
    return {
      problems: problemResults,
      total: countResults[0]?.count || 0
    };
  }

  async getProblem(id: string): Promise<Problem | undefined> {
    const [problem] = await db.select().from(problems).where(eq(problems.id, id));
    return problem;
  }

  async createProblem(problem: InsertProblem): Promise<Problem> {
    const [newProblem] = await db.insert(problems).values(problem).returning();
    return newProblem;
  }

  async updateProblem(id: string, problem: Partial<InsertProblem>): Promise<Problem> {
    const [updatedProblem] = await db
      .update(problems)
      .set({ ...problem, updatedAt: new Date() })
      .where(eq(problems.id, id))
      .returning();
    return updatedProblem;
  }

  async deleteProblem(id: string): Promise<void> {
    await db.delete(problems).where(eq(problems.id, id));
  }

  async getProblemOfTheDay(): Promise<Problem | undefined> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const [problem] = await db
      .select()
      .from(problems)
      .where(
        and(
          eq(problems.isProblemOfDay, true),
          eq(problems.problemOfDayDate, today)
        )
      );
    
    return problem;
  }

  async setProblemOfTheDay(problemId: string): Promise<void> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Remove previous problem of the day
    await db
      .update(problems)
      .set({ 
        isProblemOfDay: false, 
        problemOfDayDate: null,
        updatedAt: new Date()
      })
      .where(eq(problems.isProblemOfDay, true));
    
    // Set new problem of the day
    await db
      .update(problems)
      .set({ 
        isProblemOfDay: true, 
        problemOfDayDate: today,
        updatedAt: new Date()
      })
      .where(eq(problems.id, problemId));
  }

  // Contest operations
  async getContests(filters?: {
    status?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ contests: Contest[]; total: number }> {
    const conditions = [];
    
    if (filters?.status && filters.status !== "all") {
      conditions.push(eq(contests.status, filters.status as any));
    }
    
    if (filters?.search) {
      conditions.push(
        or(
          like(contests.title, `%${filters.search}%`),
          like(contests.description, `%${filters.search}%`)
        )!
      );
    }
    
    const whereCondition = conditions.length > 0 ? and(...conditions) : undefined;
    
    let query = db.select().from(contests);
    let countQuery = db.select({ count: count() }).from(contests);
    
    if (whereCondition) {
      query = query.where(whereCondition);
      countQuery = countQuery.where(whereCondition);
    }
    
    query = query.orderBy(desc(contests.startTime));
    
    if (filters?.limit) {
      query = query.limit(filters.limit);
    }
    
    if (filters?.offset) {
      query = query.offset(filters.offset);
    }
    
    const [contestResults, countResults] = await Promise.all([
      query,
      countQuery
    ]);
    
    return {
      contests: contestResults,
      total: countResults[0]?.count || 0
    };
  }

  async getContest(id: string): Promise<Contest | undefined> {
    const [contest] = await db.select().from(contests).where(eq(contests.id, id));
    return contest;
  }

  async createContest(contest: InsertContest): Promise<Contest> {
    const [newContest] = await db.insert(contests).values(contest).returning();
    return newContest;
  }

  async updateContest(id: string, contest: Partial<InsertContest>): Promise<Contest> {
    const [updatedContest] = await db
      .update(contests)
      .set({ ...contest, updatedAt: new Date() })
      .where(eq(contests.id, id))
      .returning();
    return updatedContest;
  }

  async deleteContest(id: string): Promise<void> {
    await db.delete(contests).where(eq(contests.id, id));
  }

  async getContestProblems(contestId: string): Promise<(ContestProblem & { problem: Problem })[]> {
    const results = await db
      .select()
      .from(contestProblems)
      .leftJoin(problems, eq(contestProblems.problemId, problems.id))
      .where(eq(contestProblems.contestId, contestId))
      .orderBy(asc(contestProblems.order));
    
    return results.map(row => ({
      ...row.contest_problems,
      problem: row.problems!
    }));
  }

  async addProblemToContest(contestId: string, problemId: string, points: number, order: number): Promise<void> {
    await db.insert(contestProblems).values({
      contestId,
      problemId,
      points,
      order
    });
  }

  // Submission operations
  async createSubmission(submission: InsertSubmission): Promise<Submission> {
    const [newSubmission] = await db.insert(submissions).values(submission).returning();
    return newSubmission;
  }

  async getSubmission(id: string): Promise<Submission | undefined> {
    const [submission] = await db.select().from(submissions).where(eq(submissions.id, id));
    return submission;
  }

  async updateSubmission(id: string, updates: Partial<Submission>): Promise<Submission> {
    const [updatedSubmission] = await db
      .update(submissions)
      .set(updates)
      .where(eq(submissions.id, id))
      .returning();
    return updatedSubmission;
  }

  async getUserSubmissions(userId: string, limit = 50): Promise<Submission[]> {
    return await db
      .select()
      .from(submissions)
      .where(eq(submissions.userId, userId))
      .orderBy(desc(submissions.submittedAt))
      .limit(limit);
  }

  async getProblemSubmissions(problemId: string, userId: string): Promise<Submission[]> {
    return await db
      .select()
      .from(submissions)
      .where(
        and(
          eq(submissions.problemId, problemId),
          eq(submissions.userId, userId)
        )
      )
      .orderBy(desc(submissions.submittedAt));
  }

  // Learning operations
  async getLearningModules(difficulty?: string): Promise<LearningModule[]> {
    const conditions = [eq(learningModules.isPublished, true)];
    
    if (difficulty) {
      conditions.push(eq(learningModules.difficulty, difficulty as any));
    }
    
    const whereCondition = and(...conditions);
    
    return await db
      .select()
      .from(learningModules)
      .where(whereCondition)
      .orderBy(asc(learningModules.order));
  }

  async getLearningModule(id: string): Promise<LearningModule | undefined> {
    const [module] = await db.select().from(learningModules).where(eq(learningModules.id, id));
    return module;
  }

  async createLearningModule(module: InsertLearningModule): Promise<LearningModule> {
    const [newModule] = await db.insert(learningModules).values(module).returning();
    return newModule;
  }

  async updateLearningModule(id: string, module: Partial<InsertLearningModule>): Promise<LearningModule> {
    const [updatedModule] = await db
      .update(learningModules)
      .set({ ...module, updatedAt: new Date() })
      .where(eq(learningModules.id, id))
      .returning();
    return updatedModule;
  }

  async getUserProgress(userId: string): Promise<(UserProgress & { module: LearningModule })[]> {
    const results = await db
      .select()
      .from(userProgress)
      .leftJoin(learningModules, eq(userProgress.moduleId, learningModules.id))
      .where(eq(userProgress.userId, userId))
      .orderBy(asc(learningModules.order));
    
    return results.map(row => ({
      ...row.user_progress,
      module: row.learning_modules!
    }));
  }

  async updateUserProgress(userId: string, moduleId: string, progress: Partial<InsertUserProgress>): Promise<UserProgress> {
    const [existingProgress] = await db
      .select()
      .from(userProgress)
      .where(
        and(
          eq(userProgress.userId, userId),
          eq(userProgress.moduleId, moduleId)
        )
      );
    
    if (existingProgress) {
      const [updatedProgress] = await db
        .update(userProgress)
        .set(progress)
        .where(eq(userProgress.id, existingProgress.id))
        .returning();
      return updatedProgress;
    } else {
      const [newProgress] = await db
        .insert(userProgress)
        .values({ userId, moduleId, ...progress })
        .returning();
      return newProgress;
    }
  }

  // Contest participation
  async registerForContest(userId: string, contestId: string): Promise<ContestParticipation> {
    const [participation] = await db
      .insert(contestParticipations)
      .values({ userId, contestId })
      .returning();
    return participation;
  }

  async getContestParticipation(userId: string, contestId: string): Promise<ContestParticipation | undefined> {
    const [participation] = await db
      .select()
      .from(contestParticipations)
      .where(
        and(
          eq(contestParticipations.userId, userId),
          eq(contestParticipations.contestId, contestId)
        )
      );
    return participation;
  }

  async getUserContestParticipations(userId: string): Promise<(ContestParticipation & { contest: Contest })[]> {
    const results = await db
      .select()
      .from(contestParticipations)
      .leftJoin(contests, eq(contestParticipations.contestId, contests.id))
      .where(eq(contestParticipations.userId, userId))
      .orderBy(desc(contestParticipations.registeredAt));
    
    return results.map(row => ({
      ...row.contest_participations,
      contest: row.contests!
    }));
  }

  // Statistics
  async getUserStats(userId: string): Promise<{
    problemsSolved: number;
    contestsJoined: number;
    rating: number;
    modulesCompleted: number;
    streak: number;
    weeklyProgress: number;
  }> {
    // Get user data
    const user = await this.getUser(userId);
    
    // Count solved problems (accepted submissions)
    const [solvedProblems] = await db
      .select({ count: count() })
      .from(submissions)
      .where(
        and(
          eq(submissions.userId, userId),
          eq(submissions.status, "accepted")
        )
      );
    
    // Count contest participations
    const [contestsJoined] = await db
      .select({ count: count() })
      .from(contestParticipations)
      .where(eq(contestParticipations.userId, userId));
    
    // Count completed modules
    const [modulesCompleted] = await db
      .select({ count: count() })
      .from(userProgress)
      .where(
        and(
          eq(userProgress.userId, userId),
          eq(userProgress.isCompleted, true)
        )
      );
    
    // Calculate weekly progress (submissions in last 7 days)
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    
    const [weeklySubmissions] = await db
      .select({ count: count() })
      .from(submissions)
      .where(
        and(
          eq(submissions.userId, userId),
          sql`${submissions.submittedAt} >= ${weekAgo}`
        )
      );
    
    return {
      problemsSolved: solvedProblems.count,
      contestsJoined: contestsJoined.count,
      rating: user?.rating || 1200,
      modulesCompleted: modulesCompleted.count,
      streak: user?.streak || 0,
      weeklyProgress: weeklySubmissions.count
    };
  }

  // Recent activity
  async getUserRecentActivity(userId: string, limit = 10): Promise<any[]> {
    // Get recent submissions
    const recentSubmissions = await db
      .select({
        id: submissions.id,
        type: sql<string>`'submission'`,
        title: problems.title,
        status: submissions.status,
        points: sql<number>`CASE WHEN ${submissions.status} = 'accepted' THEN 25 ELSE 0 END`,
        time: submissions.submittedAt,
        difficulty: problems.difficulty
      })
      .from(submissions)
      .leftJoin(problems, eq(submissions.problemId, problems.id))
      .where(eq(submissions.userId, userId))
      .orderBy(desc(submissions.submittedAt))
      .limit(limit);
    
    // Get recent module completions
    const recentModules = await db
      .select({
        id: userProgress.id,
        type: sql<string>`'module'`,
        title: learningModules.title,
        status: sql<string>`'completed'`,
        points: sql<number>`0`,
        time: userProgress.completedAt,
        difficulty: learningModules.difficulty
      })
      .from(userProgress)
      .leftJoin(learningModules, eq(userProgress.moduleId, learningModules.id))
      .where(
        and(
          eq(userProgress.userId, userId),
          eq(userProgress.isCompleted, true)
        )
      )
      .orderBy(desc(userProgress.completedAt))
      .limit(limit);
    
    // Combine and sort by time
    const allActivity = [...recentSubmissions, ...recentModules]
      .sort((a, b) => new Date(b.time!).getTime() - new Date(a.time!).getTime())
      .slice(0, limit);
    
    return allActivity;
  }
}

export const storage = new DatabaseStorage();
