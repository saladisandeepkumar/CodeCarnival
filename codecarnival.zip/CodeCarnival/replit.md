# Code Carnival - Programming Contest Platform

## Overview

Code Carnival is a full-stack web application for programming contests and practice, built with modern web technologies. It provides a comprehensive platform for competitive programming with features including problem practice, contests, learning modules, user progress tracking, and administrative tools.

## User Preferences

Preferred communication style: Simple, everyday language.

## Admin Configuration

**Admin Email**: sandeepsaladi19@gmail.com
- Only this email has admin access to manage contests
- Admin can create, edit, delete contests
- Admin can add problems to contests
- Regular users can only view and participate in contests

## Recent Changes (July 29, 2025)

**Practice Problems Expansion**:
- Added 8+ new coding problems across all difficulty levels (easy, medium, hard)
- Problems include: Valid Parentheses, Maximum Subarray, Best Time to Buy and Sell Stock, 3Sum, Container With Most Water, Longest Substring Without Repeating Characters, Median of Two Sorted Arrays, Trapping Rain Water
- All problems include starter code templates for Python, JavaScript, Java, and C++

**Learning Module System Overhaul**:
- Removed prerequisite restrictions - all modules now accessible without completing previous levels
- Reorganized learning paths by programming language instead of difficulty-based progression
- Added 8 comprehensive learning modules covering:
  - Python Fundamentals
  - Java Essentials  
  - C++ Programming
  - Web Development with JavaScript
  - Go Programming
  - Machine Learning with Python
  - React Frontend Development
  - Database Design and SQL
- Each module contains 4+ detailed lessons with estimated completion times
- Progress tracking system maintains user completion status across all modules

**User Interface Improvements**:
- New learning page layout with language-specific sections
- Specialty topics organization (Data Structures & Algorithms, Machine Learning, Web Development, Database & SQL)
- Individual module cards showing progress, difficulty, and completion status
- All modules accessible from start without unlock requirements

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for the user interface
- **Vite** as the build tool and development server
- **Wouter** for client-side routing (lightweight React router)
- **TanStack Query** for server state management and caching
- **React Hook Form** for form handling and validation
- **Tailwind CSS** for styling with custom CSS variables for theming
- **Shadcn/ui** component library for consistent UI components

### Backend Architecture
- **Express.js** server with TypeScript
- **RESTful API** design for client-server communication
- **Session-based authentication** using Replit's OpenID Connect
- **PostgreSQL** database with connection pooling via Neon
- **Drizzle ORM** for database operations with type safety

### Key Components

#### Authentication System
- Uses Replit's OIDC for authentication
- Session storage in PostgreSQL using `connect-pg-simple`
- User roles (user/admin) for access control
- Automatic redirect handling for unauthorized access

#### Database Schema
- **Users**: Profile information, ratings, streaks, roles
- **Problems**: Coding challenges with difficulty levels, topics, test cases
- **Contests**: Timed programming competitions with multiple problems
- **Submissions**: User code submissions with execution results
- **Learning Modules**: Educational content for skill development
- **Progress Tracking**: User learning progress and statistics

#### Code Editor
- Monaco Editor integration for syntax highlighting
- Multi-language support (Python, JavaScript, Java, C++, Go, C, C#)
- Language-specific starter code templates
- Real-time code editing with auto-formatting

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit OIDC, sessions stored in database
2. **Problem Practice**: Users browse problems with filtering, solve in code editor, submit solutions
3. **Contest Participation**: Users register for contests, solve problems within time limits
4. **Learning Path**: Users progress through learning modules with tracked completion
5. **Admin Management**: Admins create/manage problems, contests, and view analytics

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives for components
- **monaco-editor**: Code editor component
- **zod**: Schema validation
- **express-session**: Session management

### Authentication
- **openid-client**: OpenID Connect implementation
- **passport**: Authentication middleware
- **connect-pg-simple**: PostgreSQL session store

### Development Tools
- **Vite**: Build tool with HMR
- **TypeScript**: Type checking
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: JavaScript bundler for production

## Deployment Strategy

### Development Environment
- Vite dev server with HMR for frontend
- Express server with TypeScript compilation via `tsx`
- Database migrations managed by Drizzle Kit
- Replit-specific plugins for development experience

### Production Build
- Frontend built with Vite to static assets
- Backend bundled with ESBuild for Node.js deployment
- Single entry point serving both API and static files
- Environment variables for database and session configuration

### Database Management
- Schema defined in shared TypeScript files
- Migrations generated and applied via Drizzle Kit
- Connection pooling for production scalability
- PostgreSQL with Neon for serverless compatibility

The application follows a monorepo structure with clear separation between client, server, and shared code. The architecture emphasizes type safety, developer experience, and scalability while maintaining simplicity in deployment and maintenance.